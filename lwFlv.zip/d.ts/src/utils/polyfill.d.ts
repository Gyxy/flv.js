export default Polyfill;
declare class Polyfill {
    static install(): void;
}
