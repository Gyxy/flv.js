export default TransmuxingWorker;
declare function TransmuxingWorker(self: any): void;
