export default MSEEvents;
declare namespace MSEEvents {
    const ERROR: string;
    const SOURCE_OPEN: string;
    const UPDATE_END: string;
    const BUFFER_FULL: string;
    const LOADBUFFER: string;
}
