declare const WebSocketLoader: any;
export default WebSocketLoader;
