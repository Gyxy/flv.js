export default CustomLoader;
declare class CustomLoader extends BaseLoader {
    constructor();
    TAG: string;
    _ws: any;
    _requestAbort: boolean;
    _receivedLength: number;
    open(): void;
    _dispatchArrayBuffer(arraybuffer: any): void;
}
import { BaseLoader } from "./loader.js";
