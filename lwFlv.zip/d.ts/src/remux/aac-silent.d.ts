export default AAC;
declare class AAC {
    static getSilentFrame(codec: any, channelCount: any): Uint8Array;
}
