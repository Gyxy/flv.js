
flv.js design
======

Architecture overview:

![arch](architecture.png)
