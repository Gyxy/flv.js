export default Browser;
declare let Browser: {};
