export default decodeUTF8;
declare function decodeUTF8(uint8array: any): string;
