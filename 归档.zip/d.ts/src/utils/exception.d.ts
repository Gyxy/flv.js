export class RuntimeException {
    constructor(message: any);
    _message: any;
    get name(): string;
    get message(): any;
    toString(): string;
}
/** 非法数据异常信息抛出 */
export class IllegalStateException extends RuntimeException {
}
/** 参数错误异常信息抛出 */
export class InvalidArgumentException extends RuntimeException {
}
/** 具体方法为实现异常信息抛出 */
export class NotImplementedException extends RuntimeException {
}
