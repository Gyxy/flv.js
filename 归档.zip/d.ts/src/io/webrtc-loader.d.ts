export default webRtcLoader;
declare class webRtcLoader extends BaseLoader {
    static isSupported(): boolean;
    constructor();
    TAG: string;
    dataSource: {};
    _conn: any;
    _wrtc: any;
    _requestAbort: boolean;
    _receivedLength: number;
    open(dataSource: any): void;
    _onWebRtcOpen(e: any): void;
    _onWebRtcConOpen(e: any): void;
    _onWebRtcConData(e: any): void;
    _onWebSocketClose(e: any): void;
    _onWebSocketMessage(e: any): void;
    _dispatchArrayBuffer(arraybuffer: any): void;
    _onWebSocketError(e: any): void;
}
import { BaseLoader } from "./loader";
