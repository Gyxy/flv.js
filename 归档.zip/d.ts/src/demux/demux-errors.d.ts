export default DemuxErrors;
declare namespace DemuxErrors {
    const OK: string;
    const FORMAT_ERROR: string;
    const FORMAT_UNSUPPORTED: string;
    const CODEC_UNSUPPORTED: string;
}
